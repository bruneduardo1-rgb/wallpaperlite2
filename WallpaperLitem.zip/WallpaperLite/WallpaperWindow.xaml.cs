using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Shapes;
using Microsoft.Web.WebView2.Core;
using Forms = System.Windows.Forms;

namespace WallpaperLite
{
    // Uma janela por monitor. Toca vídeo (MediaElement) ou página HTML/WebGL (WebView2).
    public partial class WallpaperWindow : Window
    {
        delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
        [DllImport("user32.dll")] static extern IntPtr FindWindow(string cls, string title);
        [DllImport("user32.dll")] static extern IntPtr FindWindowEx(IntPtr parent, IntPtr after, string cls, string title);
        [DllImport("user32.dll")] static extern bool EnumWindows(EnumWindowsProc cb, IntPtr lParam);
        [DllImport("user32.dll")] static extern IntPtr SetParent(IntPtr child, IntPtr newParent);
        [DllImport("user32.dll")] static extern bool MoveWindow(IntPtr h, int x, int y, int w, int hgt, bool repaint);
        [DllImport("user32.dll")] static extern IntPtr SendMessageTimeout(IntPtr h, uint msg, IntPtr w, IntPtr l, uint flags, uint timeout, out IntPtr result);

        static readonly string WebDataDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "WallpaperLite", "WebView2");

        readonly Forms.Screen _screen;
        string _path;
        bool _manualPaused;
        bool _autoPaused;       // monitor coberto por app em tela cheia
        bool _released;         // conteúdo descarregado para liberar RAM
        bool _webSuspended;
        DateTime _autoPausedAt;
        TimeSpan _savedPos;

        // áudio
        bool _audioEnabled;
        double _volume = 0.5;
        bool _vizEnabled;
        Rectangle[] _bars;

        public Forms.Screen Screen => _screen;
        public System.Drawing.Rectangle ScreenBounds => _screen.Bounds;

        // Precisa de espectro de áudio? (só quando está realmente exibindo algo que o usa)
        public bool WantsAudio =>
            _path != null && !_manualPaused && !_autoPaused && !_released &&
            (IsHtml(_path) || _vizEnabled);

        public WallpaperWindow(Forms.Screen screen, string path, bool manualPaused)
        {
            InitializeComponent();
            _screen = screen;
            _path = path;
            _manualPaused = manualPaused;
            Loaded += (s, e) =>
            {
                AttachToDesktop(new WindowInteropHelper(this).Handle);
                if (_path != null) Load(_path);
            };
        }

        static bool IsHtml(string p)
        {
            var e = Path.GetExtension(p ?? "").ToLowerInvariant();
            return e == ".html" || e == ".htm";
        }

        // ---------- Desktop ----------
        void AttachToDesktop(IntPtr hwnd)
        {
            IntPtr progman = FindWindow("Progman", null);
            SendMessageTimeout(progman, 0x052C, IntPtr.Zero, IntPtr.Zero, 0, 1000, out _);

            IntPtr workerw = IntPtr.Zero;
            EnumWindows((top, _) =>
            {
                if (FindWindowEx(top, IntPtr.Zero, "SHELLDLL_DefView", null) != IntPtr.Zero)
                    workerw = FindWindowEx(IntPtr.Zero, top, "WorkerW", null);
                return true;
            }, IntPtr.Zero);

            if (workerw == IntPtr.Zero) workerw = FindWindowEx(progman, IntPtr.Zero, "WorkerW", null);
            if (workerw == IntPtr.Zero) workerw = progman;

            SetParent(hwnd, workerw);

            var virt = Forms.SystemInformation.VirtualScreen;
            var b = _screen.Bounds;
            MoveWindow(hwnd, b.X - virt.X, b.Y - virt.Y, b.Width, b.Height, true);
        }

        // ---------- Áudio ----------
        // Som só no monitor principal, para não duplicar o áudio quando o mesmo vídeo toca em vários.
        public void SetAudio(bool enabled, int volumePercent)
        {
            _audioEnabled = enabled;
            _volume = Math.Clamp(volumePercent, 0, 100) / 100.0;
            bool on = enabled && _screen.Primary;
            Player.IsMuted = !on;
            Player.Volume = _volume;
            if (Web.CoreWebView2 != null) Web.CoreWebView2.IsMuted = !on;
        }

        public void SetVisualizer(bool on)
        {
            _vizEnabled = on;
            UpdateVizVisibility();
        }

        void UpdateVizVisibility()
        {
            // O WebView2 desenha por cima de elementos WPF, então a barra interna só vale para vídeo.
            Viz.Visibility = (_vizEnabled && _path != null && !IsHtml(_path))
                ? Visibility.Visible : Visibility.Collapsed;
        }

        // Recebe o espectro (32 valores 0..1) várias vezes por segundo
        public void PushAudio(float[] bands, string json)
        {
            if (!WantsAudio) return;

            if (IsHtml(_path))
            {
                if (Web.CoreWebView2 != null && Web.Visibility == Visibility.Visible && !_webSuspended)
                {
                    try { Web.CoreWebView2.PostWebMessageAsJson(json); } catch { }
                }
            }
            else DrawBars(bands);
        }

        void EnsureBars()
        {
            if (_bars != null) return;
            _bars = new Rectangle[AudioAnalyzer.Bands];
            for (int i = 0; i < _bars.Length; i++)
            {
                var brush = new SolidColorBrush(FromHsv(190 + 130.0 * i / _bars.Length, 0.75, 1.0));
                brush.Freeze();
                _bars[i] = new Rectangle { Fill = brush, RadiusX = 2, RadiusY = 2, Opacity = 0.9 };
                Viz.Children.Add(_bars[i]);
            }
        }

        void DrawBars(float[] b)
        {
            EnsureBars();
            double w = Viz.ActualWidth, h = Viz.ActualHeight;
            if (w <= 0 || h <= 0) return;

            double slot = w / _bars.Length, bw = slot * 0.7, maxH = h * 0.35;
            for (int i = 0; i < _bars.Length; i++)
            {
                double bh = Math.Max(2, b[i] * maxH);
                _bars[i].Width = bw;
                _bars[i].Height = bh;
                Canvas.SetLeft(_bars[i], i * slot + (slot - bw) / 2);
                Canvas.SetTop(_bars[i], h - bh - h * 0.04);
            }
        }

        static Color FromHsv(double h, double s, double v)
        {
            h %= 360;
            int hi = (int)(h / 60) % 6;
            double f = h / 60 - Math.Floor(h / 60);
            double p = v * (1 - s), q = v * (1 - f * s), t = v * (1 - (1 - f) * s);
            double r, g, b;
            switch (hi)
            {
                case 0: r = v; g = t; b = p; break;
                case 1: r = q; g = v; b = p; break;
                case 2: r = p; g = v; b = t; break;
                case 3: r = p; g = q; b = v; break;
                case 4: r = t; g = p; b = v; break;
                default: r = v; g = p; b = q; break;
            }
            return Color.FromRgb((byte)(r * 255), (byte)(g * 255), (byte)(b * 255));
        }

        // ---------- Carregar ----------
        public async void Load(string path)
        {
            _path = path;
            _released = false;
            _savedPos = TimeSpan.Zero;
            UpdateVizVisibility();
            try
            {
                if (IsHtml(path))
                {
                    Player.Close();
                    Player.Visibility = Visibility.Collapsed;
                    Web.Visibility = Visibility.Visible;
                    await LoadHtml(path);
                }
                else
                {
                    if (Web.CoreWebView2 != null)
                    {
                        if (_webSuspended) { Web.CoreWebView2.Resume(); _webSuspended = false; }
                        Web.CoreWebView2.Navigate("about:blank");
                    }
                    Web.Visibility = Visibility.Collapsed;
                    Player.Visibility = Visibility.Visible;
                    Player.Source = new Uri(path);
                    Player.Play();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Não foi possível carregar o wallpaper:\n" + ex.Message +
                    "\n\nPara HTML é necessário o WebView2 Runtime (já vem no Windows 11).",
                    "WallpaperLite");
            }
        }

        async Task EnsureWeb()
        {
            if (Web.CoreWebView2 != null) return;

            var env = await CoreWebView2Environment.CreateAsync(null, WebDataDir);
            await Web.EnsureCoreWebView2Async(env);

            var core = Web.CoreWebView2;
            core.Settings.AreDefaultContextMenusEnabled = false;
            core.Settings.AreDevToolsEnabled = false;
            core.Settings.IsStatusBarEnabled = false;
            core.Settings.IsZoomControlEnabled = false;
            core.IsMuted = !(_audioEnabled && _screen.Primary);

            // Se a página terminou de carregar já pausada, suspende em seguida
            core.NavigationCompleted += async (s, e) =>
            {
                if (IsHtml(_path) && !_released && (_manualPaused || _autoPaused))
                    await SuspendWeb();
            };
        }

        async Task LoadHtml(string path)
        {
            await EnsureWeb();
            // Serve a pasta do HTML num host virtual: permite imagens, módulos JS e fetch locais
            Web.CoreWebView2.SetVirtualHostNameToFolderMapping(
                "wallpaper.local", Path.GetDirectoryName(path), CoreWebView2HostResourceAccessKind.Allow);
            Web.CoreWebView2.Navigate("https://wallpaper.local/" + Uri.EscapeDataString(Path.GetFileName(path)));
        }

        // ---------- Pausar / retomar ----------
        async Task SuspendWeb()
        {
            if (Web.CoreWebView2 == null || _webSuspended) return;
            Web.Visibility = Visibility.Hidden;      // TrySuspend exige o WebView invisível
            await Task.Delay(50);
            try { _webSuspended = await Web.CoreWebView2.TrySuspendAsync(); } catch { }
        }

        void ResumeWeb()
        {
            if (Web.CoreWebView2 == null) return;
            if (_webSuspended) { Web.CoreWebView2.Resume(); _webSuspended = false; }
            Web.Visibility = Visibility.Visible;
        }

        void PauseContent()
        {
            if (IsHtml(_path)) _ = SuspendWeb(); else Player.Pause();
        }

        void ResumeContent()
        {
            if (IsHtml(_path)) ResumeWeb(); else Player.Play();
        }

        public void SetManualPause(bool paused)
        {
            _manualPaused = paused;
            if (_path == null || _autoPaused) return;
            if (paused) PauseContent(); else ResumeContent();
        }

        // Chamado a cada segundo: covered = há app em tela cheia neste monitor
        public void SetCovered(bool covered, int releaseAfterSeconds)
        {
            if (_path == null) return;

            if (covered && !_autoPaused)
            {
                _autoPaused = true;
                _autoPausedAt = DateTime.Now;
                PauseContent();
            }
            else if (covered && _autoPaused && !_released &&
                     (DateTime.Now - _autoPausedAt).TotalSeconds > releaseAfterSeconds)
            {
                ReleaseContent();
            }
            else if (!covered && _autoPaused)
            {
                _autoPaused = false;
                if (_released) RestoreContent();
                else if (!_manualPaused) ResumeContent();
            }
        }

        void ReleaseContent()
        {
            _released = true;
            if (IsHtml(_path))
            {
                if (Web.CoreWebView2 != null)
                {
                    if (_webSuspended) { Web.CoreWebView2.Resume(); _webSuspended = false; }
                    Web.CoreWebView2.Navigate("about:blank");
                }
            }
            else
            {
                _savedPos = Player.Position;
                Player.Close();
            }
        }

        async void RestoreContent()
        {
            _released = false;
            if (IsHtml(_path))
            {
                Web.Visibility = Visibility.Visible;
                try { await LoadHtml(_path); } catch { }
            }
            else
            {
                Player.Source = new Uri(_path);   // posição restaurada em MediaOpened
                Player.Play();
            }
        }

        void Player_MediaOpened(object sender, RoutedEventArgs e)
        {
            if (_savedPos > TimeSpan.Zero)
            {
                Player.Position = _savedPos;
                _savedPos = TimeSpan.Zero;
            }
            if (_manualPaused || _autoPaused) Player.Pause();
        }

        void Player_MediaEnded(object sender, RoutedEventArgs e)
        {
            Player.Position = TimeSpan.Zero;
            Player.Play();
        }
    }
}
