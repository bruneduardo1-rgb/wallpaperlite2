using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Windows.Input;
using System.Windows.Interop;

namespace WallpaperLite
{
    // Atalhos globais (funcionam mesmo com outro app em foco) via RegisterHotKey.
    public class HotkeyManager : IDisposable
    {
        const int WM_HOTKEY = 0x0312;
        const uint MOD_ALT = 1, MOD_CONTROL = 2, MOD_SHIFT = 4, MOD_WIN = 8, MOD_NOREPEAT = 0x4000;

        [DllImport("user32.dll")] static extern bool RegisterHotKey(IntPtr h, int id, uint mods, uint vk);
        [DllImport("user32.dll")] static extern bool UnregisterHotKey(IntPtr h, int id);

        readonly HwndSource _src;
        readonly Dictionary<int, Action> _actions = new Dictionary<int, Action>();
        int _nextId = 1;

        public HotkeyManager()
        {
            // janela invisível só para receber WM_HOTKEY (HWND_MESSAGE = -3)
            var p = new HwndSourceParameters("WallpaperLiteHotkeys") { ParentWindow = new IntPtr(-3), Width = 0, Height = 0 };
            _src = new HwndSource(p);
            _src.AddHook(Hook);
        }

        IntPtr Hook(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            if (msg == WM_HOTKEY && _actions.TryGetValue(wParam.ToInt32(), out var action))
            {
                handled = true;
                action();
            }
            return IntPtr.Zero;
        }

        public void Clear()
        {
            foreach (var id in _actions.Keys) UnregisterHotKey(_src.Handle, id);
            _actions.Clear();
        }

        // false = combinação inválida ou já em uso por outro programa
        public bool Register(string combo, Action action)
        {
            if (!TryParse(combo, out uint mods, out uint vk)) return false;
            int id = _nextId++;
            if (!RegisterHotKey(_src.Handle, id, mods | MOD_NOREPEAT, vk)) return false;
            _actions[id] = action;
            return true;
        }

        public static bool TryParse(string combo, out uint mods, out uint vk)
        {
            mods = 0; vk = 0;
            if (string.IsNullOrWhiteSpace(combo)) return false;

            var parts = combo.Split('+');
            for (int i = 0; i < parts.Length - 1; i++)
            {
                switch (parts[i].Trim())
                {
                    case "Ctrl": mods |= MOD_CONTROL; break;
                    case "Alt": mods |= MOD_ALT; break;
                    case "Shift": mods |= MOD_SHIFT; break;
                    case "Win": mods |= MOD_WIN; break;
                    default: return false;
                }
            }
            if (mods == 0) return false;
            if (!Enum.TryParse(parts[parts.Length - 1].Trim(), out Key key)) return false;
            vk = (uint)KeyInterop.VirtualKeyFromKey(key);
            return vk != 0;
        }

        public static string Format(ModifierKeys m, Key key)
        {
            var s = "";
            if (m.HasFlag(ModifierKeys.Control)) s += "Ctrl+";
            if (m.HasFlag(ModifierKeys.Alt)) s += "Alt+";
            if (m.HasFlag(ModifierKeys.Shift)) s += "Shift+";
            if (m.HasFlag(ModifierKeys.Windows)) s += "Win+";
            return s + key;
        }

        public void Dispose()
        {
            Clear();
            _src.Dispose();
        }
    }
}
