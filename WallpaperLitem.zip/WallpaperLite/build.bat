@echo off
chcp 65001 >nul
title Gerar WallpaperLite.exe
cd /d "%~dp0"

dotnet --version >nul 2>&1
if errorlevel 1 (
  echo .NET SDK nao encontrado.
  echo Instale o .NET 8 SDK: https://dotnet.microsoft.com/download/dotnet/8.0
  pause
  exit /b 1
)

echo.
echo  1 = Pequeno  (~5 MB; precisa do .NET 8 Desktop Runtime no PC)
echo  2 = Completo (~100 MB; roda em qualquer PC com Windows 10/11)
echo.
choice /C 12 /N /M "Escolha 1 ou 2: "
if errorlevel 2 (set SC=true) else (set SC=false)

if exist publish rmdir /s /q publish
dotnet publish WallpaperLite.csproj -c Release --self-contained %SC% -o publish
if errorlevel 1 (
  echo.
  echo Falha ao gerar o .exe. Veja as mensagens acima.
  pause
  exit /b 1
)

echo.
echo Pronto! Seu executavel esta em:  %~dp0publish\WallpaperLite.exe
echo Os wallpapers de exemplo estao em: %~dp0publish\samples
explorer publish
pause
