using System;
using NAudio.CoreAudioApi;
using NAudio.Dsp;
using NAudio.Wave;

namespace WallpaperLite
{
    // Captura o áudio que está tocando no Windows (loopback) e calcula um espectro de 32 bandas (0..1).
    public class AudioAnalyzer : IDisposable
    {
        public const int Bands = 32;
        const int FftLen = 2048;   // 2^11
        const int FftM = 11;
        const int Hop = 1024;      // calcula a cada 1024 amostras (~47x por segundo a 48 kHz)

        readonly MMDeviceEnumerator _enum = new MMDeviceEnumerator();
        readonly float[] _ring = new float[FftLen];
        readonly float[] _hann = new float[FftLen];
        readonly Complex[] _fft = new Complex[FftLen];
        readonly float[] _raw = new float[Bands];
        readonly object _lock = new object();
        readonly int[] _lo = new int[Bands];
        readonly int[] _hi = new int[Bands];

        WasapiLoopbackCapture _cap;
        WaveFormat _fmt;
        string _deviceId;
        int _write, _sinceFft;
        long _lastTick;

        public AudioAnalyzer()
        {
            for (int i = 0; i < FftLen; i++)
                _hann[i] = (float)(0.5 - 0.5 * Math.Cos(2 * Math.PI * i / (FftLen - 1)));
        }

        public void Start()
        {
            Stop();
            try
            {
                var dev = _enum.GetDefaultAudioEndpoint(DataFlow.Render, Role.Multimedia);
                _deviceId = dev.ID;
                _cap = new WasapiLoopbackCapture(dev);
                _fmt = _cap.WaveFormat;
                BuildBands(_fmt.SampleRate);
                _cap.DataAvailable += OnData;
                _cap.StartRecording();
            }
            catch
            {
                Stop();   // sem dispositivo de saída; tenta de novo em EnsureDefaultDevice()
            }
        }

        public void Stop()
        {
            if (_cap == null) return;
            try { _cap.DataAvailable -= OnData; _cap.StopRecording(); _cap.Dispose(); } catch { }
            _cap = null;
        }

        // Reinicia a captura se o dispositivo de áudio padrão mudou (ex.: fone Bluetooth)
        public void EnsureDefaultDevice()
        {
            try
            {
                var id = _enum.GetDefaultAudioEndpoint(DataFlow.Render, Role.Multimedia).ID;
                if (_cap == null || id != _deviceId) Start();
            }
            catch { }
        }

        public float[] Snapshot(out bool fresh)
        {
            var copy = new float[Bands];
            lock (_lock) Array.Copy(_raw, copy, Bands);
            fresh = Environment.TickCount64 - _lastTick < 150;
            return copy;
        }

        void BuildBands(int sampleRate)
        {
            double binHz = (double)sampleRate / FftLen;
            double f0 = 40, f1 = Math.Min(16000, sampleRate / 2.0 - 100);
            for (int b = 0; b < Bands; b++)
            {
                double fl = f0 * Math.Pow(f1 / f0, b / (double)Bands);
                double fh = f0 * Math.Pow(f1 / f0, (b + 1) / (double)Bands);
                int lo = Math.Max(1, (int)Math.Floor(fl / binHz));
                int hi = Math.Max(lo + 1, (int)Math.Ceiling(fh / binHz));   // exclusivo
                _lo[b] = lo; _hi[b] = hi;
            }
        }

        void OnData(object sender, WaveInEventArgs e)
        {
            var fmt = _fmt;
            int ch = fmt.Channels, bytes = fmt.BitsPerSample / 8, frame = ch * bytes;
            if (frame == 0 || (fmt.BitsPerSample != 32 && fmt.BitsPerSample != 16)) return;

            int frames = e.BytesRecorded / frame;
            for (int f = 0; f < frames; f++)
            {
                float sum = 0;
                for (int c = 0; c < ch; c++)
                {
                    int off = f * frame + c * bytes;
                    sum += fmt.BitsPerSample == 32
                        ? BitConverter.ToSingle(e.Buffer, off)
                        : BitConverter.ToInt16(e.Buffer, off) / 32768f;
                }
                _ring[_write] = sum / ch;
                _write = (_write + 1) % FftLen;
                if (++_sinceFft >= Hop) { _sinceFft = 0; Compute(); }
            }
        }

        void Compute()
        {
            for (int i = 0; i < FftLen; i++)
            {
                _fft[i].X = _ring[(_write + i) % FftLen] * _hann[i];
                _fft[i].Y = 0;
            }
            FastFourierTransform.FFT(true, FftM, _fft);

            lock (_lock)
            {
                for (int b = 0; b < Bands; b++)
                {
                    float max = 0;
                    for (int k = _lo[b]; k < _hi[b]; k++)
                    {
                        float m = (float)Math.Sqrt(_fft[k].X * _fft[k].X + _fft[k].Y * _fft[k].Y);
                        if (m > max) max = m;
                    }
                    float norm = max / (FftLen / 4f);                 // 1.0 = senoide em volume máximo
                    double db = 20 * Math.Log10(norm + 1e-6) + b * 0.45; // leve realce dos agudos
                    _raw[b] = (float)Math.Clamp((db + 65) / 60, 0, 1);
                }
                _lastTick = Environment.TickCount64;
            }
        }

        public void Dispose() { Stop(); _enum.Dispose(); }
    }
}
