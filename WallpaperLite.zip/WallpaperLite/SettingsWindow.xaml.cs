using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using Forms = System.Windows.Forms;

namespace WallpaperLite
{
    public partial class SettingsWindow : Window
    {
        static readonly (string Key, string Label)[] HotkeyActions =
        {
            ("TogglePause",      "Pausar / Continuar"),
            ("ToggleSound",      "Ligar / desligar som"),
            ("ToggleVisualizer", "Ligar / desligar visualizador"),
            ("OpenSettings",     "Abrir configurações"),
        };

        readonly App _app = (App)Application.Current;
        readonly Dictionary<string, TextBox> _hotBoxes = new Dictionary<string, TextBox>();
        readonly Dictionary<string, TextBlock> _hotWarn = new Dictionary<string, TextBlock>();
        bool _loading = true;   // evita que ValueChanged durante o carregamento grave configurações

        public SettingsWindow()
        {
            InitializeComponent();
            BuildHotkeyRows();
            RefreshToggles();
            RefreshMonitors();
            RefreshHotkeys(_app.FailedHotkeys);
            _loading = false;

            _app.SettingsChanged += OnExternalChange;   // mudanças feitas por atalhos
            Closed += (s, e) =>
            {
                _app.SettingsChanged -= OnExternalChange;
                _app.SaveSettings();
            };
        }

        void OnExternalChange() => RefreshToggles();

        // ---------- Geral / Áudio ----------
        void RefreshToggles()
        {
            bool old = _loading;
            _loading = true;
            var st = _app.Settings;
            ChkAuto.IsChecked = st.AutoPause;
            SldRelease.Value = st.ReleaseSeconds;
            TxtRelease.Text = st.ReleaseSeconds + " s";
            ChkStartup.IsChecked = App.IsAutoStartEnabled();
            CmbAttach.SelectedIndex = Math.Clamp(st.AttachMode, 0, 2);
            ChkSound.IsChecked = st.AudioEnabled;
            SldVolume.Value = st.Volume;
            TxtVolume.Text = st.Volume + "%";
            ChkViz.IsChecked = st.Visualizer;
            RefreshUpdateUi();
            _loading = old;
        }

        void ChkAuto_Click(object s, RoutedEventArgs e)
        {
            _app.Settings.AutoPause = ChkAuto.IsChecked == true;
            _app.SaveSettings();
        }

        void SldRelease_ValueChanged(object s, RoutedPropertyChangedEventArgs<double> e)
        {
            if (TxtRelease != null) TxtRelease.Text = (int)SldRelease.Value + " s";
            if (_loading) return;
            _app.Settings.ReleaseSeconds = (int)SldRelease.Value;
        }

        void ChkStartup_Click(object s, RoutedEventArgs e)
        {
            bool on = ChkStartup.IsChecked == true;
            if (!App.SetAutoStart(on)) ChkStartup.IsChecked = !on;
        }

        void BtnPause_Click(object s, RoutedEventArgs e) => _app.ToggleManualPause();

        void CmbAttach_SelectionChanged(object s, SelectionChangedEventArgs e)
        {
            if (_loading || CmbAttach.SelectedIndex < 0) return;
            _app.Settings.AttachMode = CmbAttach.SelectedIndex;
            _app.SaveSettings();
            _app.RebuildWindows();      // reencaixa o wallpaper com o novo modo
        }

        void ChkSound_Click(object s, RoutedEventArgs e)
        {
            _app.Settings.AudioEnabled = ChkSound.IsChecked == true;
            _app.ApplyAudioSettings();
            _app.SaveSettings();
        }

        void SldVolume_ValueChanged(object s, RoutedPropertyChangedEventArgs<double> e)
        {
            if (TxtVolume != null) TxtVolume.Text = (int)SldVolume.Value + "%";
            if (_loading) return;
            _app.Settings.Volume = (int)SldVolume.Value;
            _app.ApplyAudioSettings();
        }

        void ChkViz_Click(object s, RoutedEventArgs e)
        {
            _app.Settings.Visualizer = ChkViz.IsChecked == true;
            _app.ApplyAudioSettings();
            _app.SaveSettings();
        }

        void BtnClose_Click(object s, RoutedEventArgs e) => Close();

        // ---------- Atualização ----------
        UpdateInfo _pending;

        void RefreshUpdateUi()
        {
            TxtVersion.Text = "Versão instalada: " + Updater.Current;
            TxtRepo.Text = _app.Settings.UpdateRepo;
            ChkCheckUpd.IsChecked = _app.Settings.CheckUpdates;
            ChkAutoInst.IsChecked = _app.Settings.AutoInstall;
        }

        void TxtRepo_LostFocus(object s, RoutedEventArgs e)
        {
            _app.Settings.UpdateRepo = TxtRepo.Text.Trim();
            _app.SaveSettings();
        }

        void ChkCheckUpd_Click(object s, RoutedEventArgs e)
        {
            _app.Settings.CheckUpdates = ChkCheckUpd.IsChecked == true;
            _app.SaveSettings();
        }

        void ChkAutoInst_Click(object s, RoutedEventArgs e)
        {
            _app.Settings.AutoInstall = ChkAutoInst.IsChecked == true;
            _app.SaveSettings();
        }

        async void BtnCheck_Click(object s, RoutedEventArgs e)
        {
            _app.Settings.UpdateRepo = TxtRepo.Text.Trim();
            _app.SaveSettings();
            BtnCheck.IsEnabled = false;
            BtnInstall.IsEnabled = false;
            _pending = null;
            TxtUpdStatus.Text = "Verificando...";
            try
            {
                var info = await _app.CheckUpdateAsync();
                if (info == null)
                    TxtUpdStatus.Text = "Não encontrei nenhum .exe na última versão publicada.";
                else if (info.Version > Updater.Current)
                {
                    _pending = info;
                    BtnInstall.IsEnabled = true;
                    TxtUpdStatus.Text = $"Nova versão disponível: {info.Version} ({info.AssetName}, {info.Size / 1048576} MB).";
                }
                else TxtUpdStatus.Text = $"Você já está na versão mais recente ({Updater.Current}).";
            }
            catch (Exception ex) { TxtUpdStatus.Text = "Não foi possível verificar: " + ex.Message; }
            finally { BtnCheck.IsEnabled = true; }
        }

        async void BtnInstall_Click(object s, RoutedEventArgs e)
        {
            if (_pending == null) return;
            BtnInstall.IsEnabled = false;
            BtnCheck.IsEnabled = false;
            PrgUpd.Value = 0;
            PrgUpd.Visibility = Visibility.Visible;
            var progress = new Progress<double>(p =>
            {
                PrgUpd.Value = p;
                TxtUpdStatus.Text = $"Baixando... {(int)(p * 100)}%";
            });
            try
            {
                TxtUpdStatus.Text = "Baixando...";
                await _app.InstallUpdateAsync(_pending, progress);   // reinicia o app ao terminar
            }
            catch (Exception ex)
            {
                TxtUpdStatus.Text = "Falha na atualização: " + ex.Message;
                PrgUpd.Visibility = Visibility.Collapsed;
                BtnCheck.IsEnabled = true;
                BtnInstall.IsEnabled = true;
            }
        }

        // ---------- Wallpapers ----------
        void RefreshMonitors()
        {
            MonitorPanel.Children.Clear();

            string def = _app.Settings.Default != null ? Path.GetFileName(_app.Settings.Default) : "(nenhum)";
            AddMonitorRow("Todos os monitores", def,
                () => { _app.PickWallpaper(null, true); RefreshMonitors(); }, null);

            var screens = Forms.Screen.AllScreens;
            for (int i = 0; i < screens.Length; i++)
            {
                var sc = screens[i];
                string title = $"Monitor {i + 1}{(sc.Primary ? " (principal)" : "")} - {sc.Bounds.Width}x{sc.Bounds.Height}";
                bool has = _app.Settings.Monitors.TryGetValue(sc.DeviceName, out var p);
                string sub = has ? Path.GetFileName(p) : "(usa o padrão)";

                AddMonitorRow(title, sub,
                    () => { _app.PickWallpaper(sc, true); RefreshMonitors(); },
                    has ? new Action(() => { _app.ClearOverride(sc); RefreshMonitors(); }) : null);
            }
        }

        void AddMonitorRow(string title, string subtitle, Action pick, Action clear)
        {
            var border = new Border
            {
                BorderBrush = Brushes.LightGray, BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(6), Padding = new Thickness(10), Margin = new Thickness(0, 0, 0, 8)
            };
            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var texts = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            texts.Children.Add(new TextBlock { Text = title, FontWeight = FontWeights.SemiBold });
            texts.Children.Add(new TextBlock
            {
                Text = subtitle, Foreground = Brushes.Gray,
                TextTrimming = TextTrimming.CharacterEllipsis, ToolTip = subtitle
            });

            var buttons = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
            var b1 = new Button { Content = "Escolher...", Padding = new Thickness(10, 3, 10, 3), Margin = new Thickness(8, 0, 0, 0) };
            b1.Click += (s, e) => pick();
            buttons.Children.Add(b1);
            if (clear != null)
            {
                var b2 = new Button { Content = "Usar padrão", Padding = new Thickness(10, 3, 10, 3), Margin = new Thickness(8, 0, 0, 0) };
                b2.Click += (s, e) => clear();
                buttons.Children.Add(b2);
            }

            Grid.SetColumn(buttons, 1);
            grid.Children.Add(texts);
            grid.Children.Add(buttons);
            border.Child = grid;
            MonitorPanel.Children.Add(border);
        }

        // ---------- Atalhos ----------
        void BuildHotkeyRows()
        {
            foreach (var (key, label) in HotkeyActions)
            {
                var row = new Grid { Margin = new Thickness(0, 0, 0, 10) };
                row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(210) });
                row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                row.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

                var name = new TextBlock { Text = label, VerticalAlignment = VerticalAlignment.Center };

                var panel = new StackPanel();
                var box = new TextBox
                {
                    IsReadOnly = true, Tag = key, Padding = new Thickness(6, 3, 6, 3),
                    IsReadOnlyCaretVisible = false, Cursor = Cursors.Hand
                };
                box.PreviewKeyDown += HotBox_PreviewKeyDown;
                var warn = new TextBlock
                {
                    Text = "Combinação inválida ou já usada por outro programa",
                    Foreground = Brushes.OrangeRed, FontSize = 11, Visibility = Visibility.Collapsed
                };
                panel.Children.Add(box);
                panel.Children.Add(warn);

                var clear = new Button { Content = "Limpar", Padding = new Thickness(10, 3, 10, 3), Margin = new Thickness(8, 0, 0, 0), VerticalAlignment = VerticalAlignment.Top };
                clear.Click += (s, e) => SetHotkey(key, "");

                Grid.SetColumn(panel, 1);
                Grid.SetColumn(clear, 2);
                row.Children.Add(name);
                row.Children.Add(panel);
                row.Children.Add(clear);
                HotkeyPanel.Children.Add(row);

                _hotBoxes[key] = box;
                _hotWarn[key] = warn;
            }
        }

        void RefreshHotkeys(ISet<string> failed)
        {
            foreach (var (key, _) in HotkeyActions)
            {
                _app.Settings.Hotkeys.TryGetValue(key, out var combo);
                _hotBoxes[key].Text = string.IsNullOrEmpty(combo) ? "(sem atalho)" : combo;
                _hotWarn[key].Visibility = failed != null && failed.Contains(key) ? Visibility.Visible : Visibility.Collapsed;
            }
        }

        void SetHotkey(string action, string combo)
        {
            _app.Settings.Hotkeys[action] = combo;
            _app.SaveSettings();
            RefreshHotkeys(_app.ApplyHotkeys());
        }

        void HotBox_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            var box = (TextBox)sender;
            var key = e.Key == Key.System ? e.SystemKey : e.Key;

            if (key == Key.Tab) return;                 // deixa navegar com Tab
            e.Handled = true;

            if (key is Key.LeftCtrl or Key.RightCtrl or Key.LeftAlt or Key.RightAlt or
                Key.LeftShift or Key.RightShift or Key.LWin or Key.RWin) return;   // só modificador

            if (key == Key.Back || key == Key.Delete) { SetHotkey((string)box.Tag, ""); return; }

            var mods = Keyboard.Modifiers;
            if (mods == ModifierKeys.None) return;      // exige ao menos um modificador

            SetHotkey((string)box.Tag, HotkeyManager.Format(mods, key));
        }
    }
}
