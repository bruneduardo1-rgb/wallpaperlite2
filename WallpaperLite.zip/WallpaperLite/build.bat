@echo off
chcp 65001 >nul
title Gerar WallpaperLite.exe
cd /d "%~dp0"

if not exist WallpaperLite.csproj (
  echo Nao encontrei o WallpaperLite.csproj nesta pasta.
  echo Extraia o zip inteiro com o botao direito e Extrair tudo, e rode o build.bat da pasta extraida.
  pause
  exit /b 1
)

dotnet --version >nul 2>&1
if errorlevel 1 goto semdotnet
goto compilar

:semdotnet
echo .NET SDK nao encontrado.
where winget >nul 2>&1
if errorlevel 1 (
  echo Instale o .NET 8 SDK em: https://dotnet.microsoft.com/download/dotnet/8.0
  echo Depois rode este build.bat de novo.
  pause
  exit /b 1
)
choice /C SN /N /M "Instalar o .NET 8 SDK agora pelo winget? (S/N): "
if errorlevel 2 exit /b 1
winget install --id Microsoft.DotNet.SDK.8 -e --accept-package-agreements --accept-source-agreements
echo.
echo Instalacao concluida. FECHE esta janela e rode o build.bat de novo.
pause
exit /b 0

:compilar
echo.
echo  1 = Pequeno  - cerca de 5 MB, precisa do .NET 8 Desktop Runtime no PC
echo  2 = Completo - cerca de 100 MB, roda em qualquer PC com Windows 10/11
echo.
choice /C 12 /N /M "Escolha 1 ou 2: "
if errorlevel 2 (set SC=true) else (set SC=false)

if exist publish rmdir /s /q publish
echo.
echo Compilando... na primeira vez baixa pacotes da internet e pode demorar.
dotnet publish WallpaperLite.csproj -c Release --self-contained %SC% -p:Version=9.0.0 -p:EnableCompressionInSingleFile=%SC% -o publish
if errorlevel 1 goto erro

echo.
echo Pronto! Seu executavel esta em:
echo %~dp0publish\WallpaperLite.exe
explorer "%~dp0publish"
pause
exit /b 0

:erro
echo.
echo Falha ao gerar o .exe. Copie as mensagens acima e envie para ajuda.
pause
exit /b 1
