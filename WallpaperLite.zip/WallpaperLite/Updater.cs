using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Text.Json;
using System.Threading.Tasks;

namespace WallpaperLite
{
    public class UpdateInfo
    {
        public Version Version;
        public string Tag;
        public string AssetName;
        public string AssetUrl;
        public long Size;
    }

    // Atualização pelo GitHub: baixa o .exe da última Release e troca o arquivo em uso.
    public static class Updater
    {
        static readonly HttpClient Http = CreateClient();

        static HttpClient CreateClient()
        {
            var c = new HttpClient { Timeout = TimeSpan.FromMinutes(15) };
            c.DefaultRequestHeaders.UserAgent.ParseAdd("WallpaperLite");
            c.DefaultRequestHeaders.Accept.ParseAdd("application/vnd.github+json");
            return c;
        }

        static Version Norm(Version v) =>
            new Version(v.Major, v.Minor, Math.Max(v.Build, 0), Math.Max(v.Revision, 0));

        public static Version Current
        {
            get
            {
                var v = Assembly.GetExecutingAssembly().GetName().Version ?? new Version(1, 0, 0, 0);
                return Norm(v);
            }
        }

        // O exe "completo" (com o .NET dentro) é bem maior que o "pequeno"
        static bool IsStandalone()
        {
            try { return new FileInfo(Environment.ProcessPath).Length > 40_000_000; }
            catch { return true; }
        }

        // repo = "usuario/repositorio" (público)
        public static async Task<UpdateInfo> CheckAsync(string repo)
        {
            if (string.IsNullOrWhiteSpace(repo) || !repo.Contains('/'))
                throw new Exception("Informe o repositório no formato usuario/repositorio.");

            using var resp = await Http.GetAsync($"https://api.github.com/repos/{repo.Trim()}/releases/latest");
            if (resp.StatusCode == HttpStatusCode.NotFound)
                throw new Exception("Nenhuma versão publicada (o repositório precisa ser público e ter uma Release).");
            resp.EnsureSuccessStatusCode();

            using var doc = JsonDocument.Parse(await resp.Content.ReadAsStringAsync());
            var root = doc.RootElement;

            string tag = root.GetProperty("tag_name").GetString() ?? "";
            if (!Version.TryParse(tag.TrimStart('v', 'V'), out var ver)) return null;

            string want = IsStandalone() ? "completo" : "pequeno";
            UpdateInfo info = null;
            foreach (var a in root.GetProperty("assets").EnumerateArray())
            {
                string name = a.GetProperty("name").GetString() ?? "";
                if (!name.EndsWith(".exe", StringComparison.OrdinalIgnoreCase)) continue;
                if (info == null || name.IndexOf(want, StringComparison.OrdinalIgnoreCase) >= 0)
                    info = new UpdateInfo
                    {
                        Version = Norm(ver),
                        Tag = tag,
                        AssetName = name,
                        AssetUrl = a.GetProperty("browser_download_url").GetString(),
                        Size = a.GetProperty("size").GetInt64()
                    };
            }
            return info;
        }

        // Baixa o novo .exe, troca o arquivo atual e abre a versão nova.
        // (Um .exe em uso pode ser renomeado, então: atual -> .old, novo -> nome original.)
        public static async Task InstallAsync(UpdateInfo info, IProgress<double> progress)
        {
            string exe = Environment.ProcessPath;
            if (exe == null || Path.GetFileNameWithoutExtension(exe).Equals("dotnet", StringComparison.OrdinalIgnoreCase))
                throw new Exception("A atualização só funciona com o WallpaperLite.exe publicado.");

            string tmpDir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "WallpaperLite", "update");
            Directory.CreateDirectory(tmpDir);
            string tmp = Path.Combine(tmpDir, "WallpaperLite-" + info.Version + ".exe");

            using (var resp = await Http.GetAsync(info.AssetUrl, HttpCompletionOption.ResponseHeadersRead))
            {
                resp.EnsureSuccessStatusCode();
                long total = resp.Content.Headers.ContentLength ?? info.Size;
                using var src = await resp.Content.ReadAsStreamAsync();
                using var dst = File.Create(tmp);
                var buf = new byte[81920];
                long done = 0;
                int n;
                while ((n = await src.ReadAsync(buf, 0, buf.Length)) > 0)
                {
                    await dst.WriteAsync(buf, 0, n);
                    done += n;
                    if (total > 0) progress?.Report((double)done / total);
                }
            }

            if (info.Size > 0 && new FileInfo(tmp).Length != info.Size)
                throw new Exception("Download incompleto. Tente de novo.");

            string old = exe + ".old";
            try
            {
                if (File.Exists(old)) File.Delete(old);
                File.Move(exe, old);
            }
            catch (UnauthorizedAccessException)
            {
                throw new Exception("Sem permissão para trocar o arquivo. Deixe o WallpaperLite.exe numa pasta sua (Área de Trabalho ou Documentos).");
            }

            try { File.Move(tmp, exe); }
            catch { File.Move(old, exe); throw; }   // desfaz se algo falhar

            Process.Start(new ProcessStartInfo(exe, "--updated")
            {
                UseShellExecute = true,
                WorkingDirectory = Path.GetDirectoryName(exe)
            });
        }
    }
}
