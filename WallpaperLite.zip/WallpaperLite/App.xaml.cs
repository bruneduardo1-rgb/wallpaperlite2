using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using Forms = System.Windows.Forms;

namespace WallpaperLite
{
    public class Settings
    {
        public string Default { get; set; }                                   // wallpaper padrão (todos os monitores)
        public Dictionary<string, string> Monitors { get; set; } = new();     // exceções por monitor
        public bool AutoPause { get; set; } = true;                           // pausar em tela cheia
        public int ReleaseSeconds { get; set; } = 30;                         // liberar RAM após N s coberto
        public int AttachMode { get; set; } = 0;                              // modo de encaixe no desktop (0, 1, 2)
        public string UpdateRepo { get; set; } = "bruneduardo1-rgb/wallpaperlite2";   // repositório das atualizações
        public bool CheckUpdates { get; set; } = true;                        // verificar ao iniciar e a cada 6 h
        public bool AutoInstall { get; set; } = true;                         // instalar sozinho quando houver versão nova
        public bool AudioEnabled { get; set; } = false;                       // som do wallpaper
        public int Volume { get; set; } = 50;                                 // 0..100
        public bool Visualizer { get; set; } = false;                         // barras reativas sobre vídeos
        public Dictionary<string, string> Hotkeys { get; set; } = new()       // atalhos globais
        {
            ["TogglePause"] = "Ctrl+Alt+P",
            ["ToggleSound"] = "Ctrl+Alt+M",
            ["ToggleVisualizer"] = "Ctrl+Alt+V",
            ["OpenSettings"] = "Ctrl+Alt+S",
        };
    }

    public partial class App : Application
    {
        const string AutoStartName = "WallpaperLite";
        const string RunKey = @"Software\Microsoft\Windows\CurrentVersion\Run";

        const string FileFilter =
            "Wallpapers|*.mp4;*.wmv;*.avi;*.mkv;*.mov;*.html;*.htm|" +
            "Vídeos|*.mp4;*.wmv;*.avi;*.mkv;*.mov|" +
            "Páginas HTML/WebGL|*.html;*.htm|Todos|*.*";

        [StructLayout(LayoutKind.Sequential)] struct RECT { public int Left, Top, Right, Bottom; }
        delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
        [DllImport("user32.dll")] static extern IntPtr FindWindow(string cls, string title);
        [DllImport("user32.dll")] static extern bool EnumWindows(EnumWindowsProc cb, IntPtr lParam);
        [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
        [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
        [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h, out RECT r);
        [DllImport("user32.dll")] static extern int GetWindowLong(IntPtr h, int index);
        [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassName(IntPtr h, StringBuilder sb, int max);
        [DllImport("dwmapi.dll")] static extern int DwmGetWindowAttribute(IntPtr h, int attr, out int value, int size);

        static readonly string SettingsFile = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "WallpaperLite", "settings.json");

        readonly List<WallpaperWindow> _windows = new List<WallpaperWindow>();
        readonly AudioAnalyzer _analyzer = new AudioAnalyzer();
        readonly float[] _smooth = new float[AudioAnalyzer.Bands];
        Settings _settings = new Settings();
        HotkeyManager _hotkeys;
        SettingsWindow _settingsWin;
        Forms.NotifyIcon _tray;
        DispatcherTimer _timer;
        DispatcherTimer _audioTimer;
        Mutex _mutex;
        bool _audioRunning;
        bool _installing;
        Version _notifiedVersion;
        bool _manualPaused;
        bool[] _lastCovered = new bool[0];

        internal Settings Settings => _settings;
        internal HashSet<string> FailedHotkeys { get; private set; } = new HashSet<string>();
        internal event Action SettingsChanged;     // disparado quando um atalho altera algo

        async void App_Startup(object sender, StartupEventArgs e)
        {
            DispatcherUnhandledException += (s, a) => { Log.Write("ERRO: " + a.Exception); a.Handled = true; };
            try { await StartupAsync(e); }
            catch (Exception ex)
            {
                Log.Write("ERRO na inicialização: " + ex);
                MessageBox.Show("Erro ao iniciar:\n" + ex.Message + "\n\nDetalhes em: " + Log.FilePath, "WallpaperLite");
                Shutdown();
            }
        }

        async Task StartupAsync(StartupEventArgs e)
        {
            Log.Write($"Iniciando. Windows {Environment.OSVersion.Version}, exe={Environment.ProcessPath}");

            // Só uma instância (evita duplicar janelas se o autostart e o usuário abrirem juntos)
            bool updated = e.Args.Contains("--updated");
            bool created;
            for (int tries = 0; ; tries++)
            {
                _mutex = new Mutex(true, "WallpaperLite_SingleInstance", out created);
                if (created || !updated || tries >= 30) break;
                _mutex.Dispose();
                await Task.Delay(500);   // após atualizar, espera a versão antiga fechar
            }
            try { if (Environment.ProcessPath != null) File.Delete(Environment.ProcessPath + ".old"); } catch { }
            if (!created)
            {
                MessageBox.Show("O WallpaperLite já está em execução. Procure o ícone perto do relógio " +
                    "(ou encerre o WallpaperLite no Gerenciador de Tarefas e abra de novo).", "WallpaperLite");
                Shutdown();
                return;
            }

            // No login, espera o Explorer criar a área de trabalho
            for (int i = 0; i < 60 && FindWindow("Progman", null) == IntPtr.Zero; i++)
                await Task.Delay(500);
            if (e.Args.Contains("--startup")) await Task.Delay(3000);

            LoadSettings();
            if (_settings.Default == null && _settings.Monitors.Count == 0) PickWallpaper(null, false);

            CreateTray();
            BuildWindows();

            _hotkeys = new HotkeyManager();
            ApplyHotkeys();

            Microsoft.Win32.SystemEvents.DisplaySettingsChanged += (s, a) =>
                Dispatcher.BeginInvoke(new Action(BuildWindows));

            _timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
            _timer.Tick += (s, a) => { CheckFullscreen(); UpdateAudioPipeline(); };
            _timer.Start();

            _audioTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(33) };   // ~30 fps
            _audioTimer.Tick += (s, a) => AudioTick();

            _ = BackgroundUpdateLoopAsync();
        }

        protected override void OnExit(ExitEventArgs e)
        {
            _hotkeys?.Dispose();
            _analyzer.Dispose();
            try { _mutex?.ReleaseMutex(); } catch { }
            base.OnExit(e);
        }

        // ---------- Configurações ----------
        void LoadSettings()
        {
            try
            {
                if (File.Exists(SettingsFile))
                    _settings = JsonSerializer.Deserialize<Settings>(File.ReadAllText(SettingsFile)) ?? new Settings();
            }
            catch { _settings = new Settings(); }
        }

        internal void SaveSettings()
        {
            Directory.CreateDirectory(Path.GetDirectoryName(SettingsFile));
            File.WriteAllText(SettingsFile,
                JsonSerializer.Serialize(_settings, new JsonSerializerOptions { WriteIndented = true }));
        }

        string ResolvePath(Forms.Screen screen)
        {
            if (_settings.Monitors.TryGetValue(screen.DeviceName, out var p) && File.Exists(p)) return p;
            if (_settings.Default != null && File.Exists(_settings.Default)) return _settings.Default;
            return null;
        }

        // target == null: todos os monitores
        internal void PickWallpaper(Forms.Screen target, bool applyNow)
        {
            var dlg = new Microsoft.Win32.OpenFileDialog { Filter = FileFilter };
            if (dlg.ShowDialog() != true) return;

            if (target == null)
            {
                _settings.Default = dlg.FileName;
                _settings.Monitors.Clear();
            }
            else _settings.Monitors[target.DeviceName] = dlg.FileName;
            SaveSettings();

            if (!applyNow) return;
            foreach (var w in _windows)
            {
                if (target != null && w.Screen.DeviceName != target.DeviceName) continue;
                var p = ResolvePath(w.Screen);
                if (p != null) w.Load(p);
            }
        }

        internal void ClearOverride(Forms.Screen screen)
        {
            _settings.Monitors.Remove(screen.DeviceName);
            SaveSettings();
            var w = _windows.FirstOrDefault(x => x.Screen.DeviceName == screen.DeviceName);
            var p = ResolvePath(screen);
            if (w != null && p != null) w.Load(p);
        }

        // ---------- Janelas ----------
        internal void RebuildWindows() => BuildWindows();

        internal void TestAttach()
        {
            Log.Write("Teste de encaixe iniciado");
            foreach (var w in _windows) w.ShowTestPattern(10);
        }

        void BuildWindows()
        {
            WallpaperWindow.AttachMode = _settings.AttachMode;
            foreach (var w in _windows) w.Close();
            _windows.Clear();

            foreach (var screen in Forms.Screen.AllScreens)
            {
                Log.Write($"Janela {screen.DeviceName}: {ResolvePath(screen) ?? "(sem wallpaper)"}");
                var w = new WallpaperWindow(screen, ResolvePath(screen), _manualPaused);
                w.SetAudio(_settings.AudioEnabled, _settings.Volume);
                w.SetVisualizer(_settings.Visualizer);
                _windows.Add(w);
                w.Show();
            }
        }

        internal void ApplyAudioSettings()
        {
            foreach (var w in _windows)
            {
                w.SetAudio(_settings.AudioEnabled, _settings.Volume);
                w.SetVisualizer(_settings.Visualizer);
            }
        }

        internal void ToggleManualPause()
        {
            _manualPaused = !_manualPaused;
            foreach (var w in _windows) w.SetManualPause(_manualPaused);
        }

        // ---------- Atalhos globais ----------
        internal HashSet<string> ApplyHotkeys()
        {
            _hotkeys.Clear();
            var failed = new HashSet<string>();

            var actions = new Dictionary<string, Action>
            {
                ["TogglePause"] = ToggleManualPause,
                ["ToggleSound"] = () =>
                {
                    _settings.AudioEnabled = !_settings.AudioEnabled;
                    SaveSettings(); ApplyAudioSettings(); SettingsChanged?.Invoke();
                },
                ["ToggleVisualizer"] = () =>
                {
                    _settings.Visualizer = !_settings.Visualizer;
                    SaveSettings(); ApplyAudioSettings(); SettingsChanged?.Invoke();
                },
                ["OpenSettings"] = OpenSettings,
            };

            foreach (var kv in actions)
            {
                if (_settings.Hotkeys.TryGetValue(kv.Key, out var combo) && !string.IsNullOrWhiteSpace(combo))
                    if (!_hotkeys.Register(combo, kv.Value)) failed.Add(kv.Key);
            }

            FailedHotkeys = failed;
            return failed;
        }

        // ---------- Tela cheia por monitor ----------
        void CheckFullscreen()
        {
            var covered = new bool[_windows.Count];
            var blame = new string[_windows.Count];

            if (_settings.AutoPause)
            {
                uint myPid = (uint)Environment.ProcessId;
                var cls = new StringBuilder(256);

                EnumWindows((h, _) =>
                {
                    if (!IsWindowVisible(h) || IsIconic(h)) return true;

                    GetWindowThreadProcessId(h, out uint pid);
                    if (pid == myPid) return true;

                    int ex = GetWindowLong(h, -20);
                    if ((ex & 0x20) != 0 || (ex & 0x80) != 0 || (ex & 0x08000000) != 0) return true;

                    if (DwmGetWindowAttribute(h, 14, out int cloaked, 4) == 0 && cloaked != 0) return true;

                    cls.Clear();
                    GetClassName(h, cls, cls.Capacity);
                    string c = cls.ToString();
                    if (c == "Progman" || c == "WorkerW" || c == "Shell_TrayWnd" || c == "Shell_SecondaryTrayWnd")
                        return true;

                    if (!GetWindowRect(h, out RECT r)) return true;

                    for (int i = 0; i < _windows.Count; i++)
                    {
                        var b = _windows[i].ScreenBounds;
                        if (r.Left <= b.Left && r.Top <= b.Top && r.Right >= b.Right && r.Bottom >= b.Bottom)
                        { covered[i] = true; blame[i] = blame[i] ?? (c + " (pid " + pid + ")"); }
                    }
                    return true;
                }, IntPtr.Zero);
            }

            for (int i = 0; i < _windows.Count; i++)
                _windows[i].SetCovered(covered[i], _settings.ReleaseSeconds);

            if (!covered.SequenceEqual(_lastCovered))
            {
                for (int i = 0; i < covered.Length; i++)
                    if (i >= _lastCovered.Length || covered[i] != _lastCovered[i])
                        Log.Write($"Monitor {i + 1}: " + (covered[i] ? "coberto por " + blame[i] : "liberado"));
                _lastCovered = covered;
            }
        }

        // ---------- Áudio reativo ----------
        // A captura só roda quando algum monitor está exibindo algo que usa o espectro.
        void UpdateAudioPipeline()
        {
            bool want = _windows.Any(w => w.WantsAudio);

            if (want && !_audioRunning)
            {
                _analyzer.Start();
                _audioTimer.Start();
                _audioRunning = true;
            }
            else if (!want && _audioRunning)
            {
                _audioTimer.Stop();
                _analyzer.Stop();
                _audioRunning = false;
                Array.Clear(_smooth, 0, _smooth.Length);
            }
            else if (want) _analyzer.EnsureDefaultDevice();
        }

        void AudioTick()
        {
            var raw = _analyzer.Snapshot(out bool fresh);

            // Ataque rápido, queda suave. Sem áudio novo, as barras descem sozinhas.
            for (int i = 0; i < _smooth.Length; i++)
            {
                float t = fresh ? raw[i] : 0f;
                _smooth[i] = t > _smooth[i] ? t : _smooth[i] * 0.85f + t * 0.15f;
            }

            var sb = new StringBuilder("{\"type\":\"audio\",\"bands\":[");
            for (int i = 0; i < _smooth.Length; i++)
            {
                if (i > 0) sb.Append(',');
                sb.Append(_smooth[i].ToString("0.###", System.Globalization.CultureInfo.InvariantCulture));
            }
            sb.Append("]}");
            string json = sb.ToString();

            foreach (var w in _windows) w.PushAudio(_smooth, json);
        }

        // ---------- Atualização pelo GitHub ----------
        internal Task<UpdateInfo> CheckUpdateAsync() => Updater.CheckAsync(_settings.UpdateRepo);

        internal async Task InstallUpdateAsync(UpdateInfo info, IProgress<double> progress)
        {
            _installing = true;
            try
            {
                Log.Write($"Instalando atualização {info.Version} ({info.AssetName})");
                await Updater.InstallAsync(info, progress);
            }
            catch (Exception ex)
            {
                _installing = false;
                Log.Write("Falha na atualização: " + ex.Message);
                throw;
            }

            Log.Write("Atualização instalada; reiniciando");
            if (_tray != null) { _tray.Visible = false; _tray.Dispose(); }
            Shutdown();
        }

        async Task BackgroundUpdateLoopAsync()
        {
            await Task.Delay(TimeSpan.FromSeconds(15));
            while (true)
            {
                if (_settings.CheckUpdates && !_installing)
                {
                    try
                    {
                        var info = await Updater.CheckAsync(_settings.UpdateRepo);
                        if (info != null && info.Version > Updater.Current)
                        {
                            Log.Write($"Atualização encontrada: {info.Version} (atual {Updater.Current})");
                            if (_settings.AutoInstall)
                            {
                                _tray?.ShowBalloonTip(4000, "WallpaperLite", $"Atualizando para a versão {info.Version}...", Forms.ToolTipIcon.Info);
                                await InstallUpdateAsync(info, null);
                                return;
                            }
                            if (_notifiedVersion != info.Version)
                            {
                                _notifiedVersion = info.Version;
                                _tray?.ShowBalloonTip(6000, "WallpaperLite",
                                    $"Versão {info.Version} disponível. Abra Configurações > Atualização.", Forms.ToolTipIcon.Info);
                            }
                        }
                    }
                    catch (Exception ex) { Log.Write("Verificação de atualização falhou: " + ex.Message); }
                }
                await Task.Delay(TimeSpan.FromHours(6));
            }
        }

        // Item "Verificar atualizações" do menu da bandeja
        async Task CheckUpdateFromMenuAsync()
        {
            if (_installing) return;
            try
            {
                _tray?.ShowBalloonTip(2000, "WallpaperLite", "Verificando atualizações...", Forms.ToolTipIcon.Info);
                var info = await Updater.CheckAsync(_settings.UpdateRepo);

                if (info == null)
                {
                    MessageBox.Show("Não encontrei nenhum .exe na última versão publicada.", "WallpaperLite");
                    return;
                }
                if (info.Version <= Updater.Current)
                {
                    MessageBox.Show($"Você já está na versão mais recente ({Updater.Current}).", "WallpaperLite");
                    return;
                }

                var r = MessageBox.Show(
                    $"Nova versão disponível: {info.Version} (instalada: {Updater.Current}).\n\n" +
                    "Atualizar agora? O wallpaper reinicia em alguns segundos.",
                    "WallpaperLite", MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (r != MessageBoxResult.Yes) return;

                _tray?.ShowBalloonTip(5000, "WallpaperLite", "Baixando a atualização...", Forms.ToolTipIcon.Info);
                await InstallUpdateAsync(info, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Não foi possível atualizar:\n" + ex.Message, "WallpaperLite");
            }
        }

        // ---------- Iniciar com o Windows ----------
        internal static bool IsAutoStartEnabled()
        {
            using var k = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(RunKey);
            return k?.GetValue(AutoStartName) != null;
        }

        internal static bool SetAutoStart(bool on)
        {
            using var k = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(RunKey, true);
            if (k == null) return false;

            if (on)
            {
                string exe = Environment.ProcessPath;
                if (exe == null || Path.GetFileNameWithoutExtension(exe).Equals("dotnet", StringComparison.OrdinalIgnoreCase))
                {
                    MessageBox.Show("Execute o WallpaperLite.exe (gerado pelo build.bat) para ativar o início com o Windows.",
                        "WallpaperLite");
                    return false;
                }
                k.SetValue(AutoStartName, $"\"{exe}\" --startup");
            }
            else k.DeleteValue(AutoStartName, false);
            return true;
        }

        // ---------- Bandeja ----------
        void CreateTray()
        {
            var menu = new Forms.ContextMenuStrip();
            menu.Items.Add("Configurações...", null, (s, a) => OpenSettings());
            menu.Items.Add("Verificar atualizações", null, async (s, a) => await CheckUpdateFromMenuAsync());
            menu.Items.Add("Pausar / Continuar", null, (s, a) => ToggleManualPause());
            menu.Items.Add(new Forms.ToolStripSeparator());
            menu.Items.Add("Sair", null, (s, a) =>
            {
                _tray.Visible = false;
                _tray.Dispose();
                Shutdown();
            });

            System.Drawing.Icon icon = null;
            try { icon = System.Drawing.Icon.ExtractAssociatedIcon(Environment.ProcessPath); } catch { }

            _tray = new Forms.NotifyIcon
            {
                Icon = icon ?? System.Drawing.SystemIcons.Application,
                Text = "WallpaperLite",
                ContextMenuStrip = menu,
                Visible = true
            };
            _tray.DoubleClick += (s, a) => OpenSettings();
        }

        internal void OpenSettings()
        {
            if (_settingsWin != null)
            {
                if (_settingsWin.WindowState == WindowState.Minimized) _settingsWin.WindowState = WindowState.Normal;
                _settingsWin.Activate();
                return;
            }
            _settingsWin = new SettingsWindow();
            _settingsWin.Closed += (s, a) => _settingsWin = null;
            _settingsWin.Show();
            _settingsWin.Activate();
        }
    }
}
