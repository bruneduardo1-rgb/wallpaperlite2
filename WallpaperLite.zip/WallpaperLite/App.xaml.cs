using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using Forms = System.Windows.Forms;

namespace WallpaperLite
{
    public class Settings
    {
        public string Default { get; set; }                                   // wallpaper padrão (todos os monitores)
        public List<string> Library { get; set; } = new List<string>(); // biblioteca persistente de wallpapers
        public Dictionary<string, string> Monitors { get; set; } = new();     // exceções por monitor
        public bool AutoPause { get; set; } = true;                           // pausar em tela cheia
        public int ReleaseSeconds { get; set; } = 30;                         // liberar RAM após N s coberto
        public bool AudioEnabled { get; set; } = false;                       // som do wallpaper
        public int Volume { get; set; } = 50;                                 // 0..100
        public bool Visualizer { get; set; } = false;                         // barras reativas sobre vídeos
        public Dictionary<string, string> Hotkeys { get; set; } = new()       // atalhos globais
        {
            ["TogglePause"] = "Ctrl+Alt+P",
            ["ToggleSound"] = "Ctrl+Alt+M",
            ["ToggleVisualizer"] = "Ctrl+Alt+V",
            ["OpenSettings"] = "Ctrl+Alt+S",
        };
    }

    public partial class App : Application
    {
        const string AutoStartName = "WallpaperLite";
        const string RunKey = @"Software\Microsoft\Windows\CurrentVersion\Run";

        const string FileFilter =
            "Wallpapers|*.mp4;*.wmv;*.avi;*.mkv;*.mov;*.html;*.htm|" +
            "Vídeos|*.mp4;*.wmv;*.avi;*.mkv;*.mov|" +
            "Páginas HTML/WebGL|*.html;*.htm|Todos|*.*";

        [StructLayout(LayoutKind.Sequential)] struct RECT { public int Left, Top, Right, Bottom; }
        delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
        [DllImport("user32.dll")] static extern IntPtr FindWindow(string cls, string title);
        [DllImport("user32.dll")] static extern bool EnumWindows(EnumWindowsProc cb, IntPtr lParam);
        [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
        [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
        [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h, out RECT r);
        [DllImport("user32.dll")] static extern int GetWindowLong(IntPtr h, int index);
        [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassName(IntPtr h, StringBuilder sb, int max);
        [DllImport("dwmapi.dll")] static extern int DwmGetWindowAttribute(IntPtr h, int attr, out int value, int size);

        static readonly string SettingsFile = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "WallpaperLite", "settings.json");

        readonly List<WallpaperWindow> _windows = new List<WallpaperWindow>();
        readonly AudioAnalyzer _analyzer = new AudioAnalyzer();
        readonly float[] _smooth = new float[AudioAnalyzer.Bands];
        Settings _settings = new Settings();
        HotkeyManager _hotkeys;
        SettingsWindow _settingsWin;
        Forms.NotifyIcon _tray;
        DispatcherTimer _timer;
        DispatcherTimer _audioTimer;
        Mutex _mutex;
        bool _audioRunning;
        bool _manualPaused;

        internal Settings Settings => _settings;
        internal HashSet<string> FailedHotkeys { get; private set; } = new HashSet<string>();
        internal event Action SettingsChanged;     // disparado quando um atalho altera algo

        async void App_Startup(object sender, StartupEventArgs e)
        {
            // Só uma instância (evita duplicar janelas se o autostart e o usuário abrirem juntos)
            _mutex = new Mutex(true, "WallpaperLite_SingleInstance", out bool created);
            if (!created) { Shutdown(); return; }

            // No login, espera o Explorer criar a área de trabalho
            for (int i = 0; i < 60 && FindWindow("Progman", null) == IntPtr.Zero; i++)
                await Task.Delay(500);
            if (e.Args.Contains("--startup")) await Task.Delay(3000);

            LoadSettings();
            if (_settings.Default == null && _settings.Monitors.Count == 0) PickWallpaper(null, false);

            CreateTray();
            BuildWindows();

            _hotkeys = new HotkeyManager();
            ApplyHotkeys();

            Microsoft.Win32.SystemEvents.DisplaySettingsChanged += (s, a) =>
                Dispatcher.BeginInvoke(new Action(BuildWindows));

            _timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
            _timer.Tick += (s, a) => { CheckFullscreen(); UpdateAudioPipeline(); };
            _timer.Start();

            _audioTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(33) };   // ~30 fps
            _audioTimer.Tick += (s, a) => AudioTick();

            // Ao abrir manualmente, mostra a janela principal e mantém o ícone na bandeja.
            // No início automático do Windows (--startup), inicia discretamente apenas na bandeja.
            if (!e.Args.Contains("--startup"))
                OpenSettings();
        }

        protected override void OnExit(ExitEventArgs e)
        {
            _hotkeys?.Dispose();
            _analyzer.Dispose();
            try { _mutex?.ReleaseMutex(); } catch { }
            base.OnExit(e);
        }

        // ---------- Configurações ----------
        void LoadSettings()
        {
            try
            {
                if (File.Exists(SettingsFile))
                    _settings = JsonSerializer.Deserialize<Settings>(File.ReadAllText(SettingsFile)) ?? new Settings();
            }
            catch { _settings = new Settings(); }
        }

        internal void SaveSettings()
        {
            Directory.CreateDirectory(Path.GetDirectoryName(SettingsFile));
            File.WriteAllText(SettingsFile,
                JsonSerializer.Serialize(_settings, new JsonSerializerOptions { WriteIndented = true }));
        }

        string ResolvePath(Forms.Screen screen)
        {
            if (_settings.Monitors.TryGetValue(screen.DeviceName, out var p) && File.Exists(p)) return p;
            if (_settings.Default != null && File.Exists(_settings.Default)) return _settings.Default;
            return null;
        }

        // target == null: todos os monitores
        internal void PickWallpaper(Forms.Screen target, bool applyNow)
        {
            var dlg = new Microsoft.Win32.OpenFileDialog { Filter = FileFilter };
            if (dlg.ShowDialog() != true) return;

            if (target == null)
            {
                _settings.Default = dlg.FileName;
                _settings.Monitors.Clear();
            }
            else _settings.Monitors[target.DeviceName] = dlg.FileName;
            SaveSettings();

            if (!applyNow) return;
            foreach (var w in _windows)
            {
                if (target != null && w.Screen.DeviceName != target.DeviceName) continue;
                var p = ResolvePath(w.Screen);
                if (p != null) w.Load(p);
            }
        }

        internal void AddToLibrary(string path)
        {
            if (string.IsNullOrWhiteSpace(path) || !File.Exists(path)) return;
            if (_settings.Library == null) _settings.Library = new List<string>();
            if (!_settings.Library.Exists(x => string.Equals(x, path, StringComparison.OrdinalIgnoreCase)))
                _settings.Library.Add(path);
            SaveSettings();
        }

        internal void RemoveFromLibrary(string path)
        {
            _settings.Library?.RemoveAll(x => string.Equals(x, path, StringComparison.OrdinalIgnoreCase));
            SaveSettings();
        }

        internal void ApplyLibraryWallpaper(string path)
        {
            if (string.IsNullOrWhiteSpace(path) || !File.Exists(path))
            {
                MessageBox.Show("O arquivo não foi encontrado. Adicione o wallpaper novamente.", "WallpaperLite",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            _settings.Default = path;
            _settings.Monitors.Clear();
            AddToLibrary(path);
            SaveSettings();
            foreach (var w in _windows) w.Load(path);
            SettingsChanged?.Invoke();
        }

        internal void ClearOverride(Forms.Screen screen)
        {
            _settings.Monitors.Remove(screen.DeviceName);
            SaveSettings();
            var w = _windows.FirstOrDefault(x => x.Screen.DeviceName == screen.DeviceName);
            var p = ResolvePath(screen);
            if (w != null && p != null) w.Load(p);
        }

        // ---------- Janelas ----------
        void BuildWindows()
        {
            foreach (var w in _windows) w.Close();
            _windows.Clear();

            foreach (var screen in Forms.Screen.AllScreens)
            {
                var w = new WallpaperWindow(screen, ResolvePath(screen), _manualPaused);
                w.SetAudio(_settings.AudioEnabled, _settings.Volume);
                w.SetVisualizer(_settings.Visualizer);
                _windows.Add(w);
                w.Show();
            }
        }

        internal void ApplyAudioSettings()
        {
            foreach (var w in _windows)
            {
                w.SetAudio(_settings.AudioEnabled, _settings.Volume);
                w.SetVisualizer(_settings.Visualizer);
            }
        }

        internal void ToggleManualPause()
        {
            _manualPaused = !_manualPaused;
            foreach (var w in _windows) w.SetManualPause(_manualPaused);
        }

        // ---------- Atalhos globais ----------
        internal HashSet<string> ApplyHotkeys()
        {
            _hotkeys.Clear();
            var failed = new HashSet<string>();

            var actions = new Dictionary<string, Action>
            {
                ["TogglePause"] = ToggleManualPause,
                ["ToggleSound"] = () =>
                {
                    _settings.AudioEnabled = !_settings.AudioEnabled;
                    SaveSettings(); ApplyAudioSettings(); SettingsChanged?.Invoke();
                },
                ["ToggleVisualizer"] = () =>
                {
                    _settings.Visualizer = !_settings.Visualizer;
                    SaveSettings(); ApplyAudioSettings(); SettingsChanged?.Invoke();
                },
                ["OpenSettings"] = OpenSettings,
            };

            foreach (var kv in actions)
            {
                if (_settings.Hotkeys.TryGetValue(kv.Key, out var combo) && !string.IsNullOrWhiteSpace(combo))
                    if (!_hotkeys.Register(combo, kv.Value)) failed.Add(kv.Key);
            }

            FailedHotkeys = failed;
            return failed;
        }

        // ---------- Tela cheia por monitor ----------
        void CheckFullscreen()
        {
            var covered = new bool[_windows.Count];

            if (_settings.AutoPause)
            {
                uint myPid = (uint)Environment.ProcessId;
                var cls = new StringBuilder(256);

                EnumWindows((h, _) =>
                {
                    if (!IsWindowVisible(h) || IsIconic(h)) return true;

                    GetWindowThreadProcessId(h, out uint pid);
                    if (pid == myPid) return true;

                    int ex = GetWindowLong(h, -20);
                    if ((ex & 0x20) != 0 || (ex & 0x80) != 0 || (ex & 0x08000000) != 0) return true;

                    if (DwmGetWindowAttribute(h, 14, out int cloaked, 4) == 0 && cloaked != 0) return true;

                    cls.Clear();
                    GetClassName(h, cls, cls.Capacity);
                    string c = cls.ToString();
                    if (c == "Progman" || c == "WorkerW" || c == "Shell_TrayWnd" || c == "Shell_SecondaryTrayWnd")
                        return true;

                    if (!GetWindowRect(h, out RECT r)) return true;

                    for (int i = 0; i < _windows.Count; i++)
                    {
                        var b = _windows[i].ScreenBounds;
                        if (r.Left <= b.Left && r.Top <= b.Top && r.Right >= b.Right && r.Bottom >= b.Bottom)
                            covered[i] = true;
                    }
                    return true;
                }, IntPtr.Zero);
            }

            for (int i = 0; i < _windows.Count; i++)
                _windows[i].SetCovered(covered[i], _settings.ReleaseSeconds);
        }

        // ---------- Áudio reativo ----------
        // A captura só roda quando algum monitor está exibindo algo que usa o espectro.
        void UpdateAudioPipeline()
        {
            bool want = _windows.Any(w => w.WantsAudio);

            if (want && !_audioRunning)
            {
                _analyzer.Start();
                _audioTimer.Start();
                _audioRunning = true;
            }
            else if (!want && _audioRunning)
            {
                _audioTimer.Stop();
                _analyzer.Stop();
                _audioRunning = false;
                Array.Clear(_smooth, 0, _smooth.Length);
            }
            else if (want) _analyzer.EnsureDefaultDevice();
        }

        void AudioTick()
        {
            var raw = _analyzer.Snapshot(out bool fresh);

            // Ataque rápido, queda suave. Sem áudio novo, as barras descem sozinhas.
            for (int i = 0; i < _smooth.Length; i++)
            {
                float t = fresh ? raw[i] : 0f;
                _smooth[i] = t > _smooth[i] ? t : _smooth[i] * 0.85f + t * 0.15f;
            }

            var sb = new StringBuilder("{\"type\":\"audio\",\"bands\":[");
            for (int i = 0; i < _smooth.Length; i++)
            {
                if (i > 0) sb.Append(',');
                sb.Append(_smooth[i].ToString("0.###", System.Globalization.CultureInfo.InvariantCulture));
            }
            sb.Append("]}");
            string json = sb.ToString();

            foreach (var w in _windows) w.PushAudio(_smooth, json);
        }

        // ---------- Iniciar com o Windows ----------
        internal static bool IsAutoStartEnabled()
        {
            using var k = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(RunKey);
            return k?.GetValue(AutoStartName) != null;
        }

        internal static bool SetAutoStart(bool on)
        {
            using var k = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(RunKey, true);
            if (k == null) return false;

            if (on)
            {
                string exe = Environment.ProcessPath;
                if (exe == null || Path.GetFileNameWithoutExtension(exe).Equals("dotnet", StringComparison.OrdinalIgnoreCase))
                {
                    MessageBox.Show("Execute o WallpaperLite.exe (gerado pelo build.bat) para ativar o início com o Windows.",
                        "WallpaperLite");
                    return false;
                }
                k.SetValue(AutoStartName, $"\"{exe}\" --startup");
            }
            else k.DeleteValue(AutoStartName, false);
            return true;
        }

        // ---------- Bandeja ----------
        void CreateTray()
        {
            var menu = new Forms.ContextMenuStrip();
            menu.Items.Add("Abrir WallpaperLite...", null, (s, a) => OpenSettings());
            menu.Items.Add("Pausar / Continuar", null, (s, a) => ToggleManualPause());
            menu.Items.Add(new Forms.ToolStripSeparator());
            menu.Items.Add("Sair", null, (s, a) =>
            {
                _tray.Visible = false;
                _tray.Dispose();
                Shutdown();
            });

            System.Drawing.Icon icon = null;
            try { icon = System.Drawing.Icon.ExtractAssociatedIcon(Environment.ProcessPath); } catch { }

            _tray = new Forms.NotifyIcon
            {
                Icon = icon ?? System.Drawing.SystemIcons.Application,
                Text = "WallpaperLite",
                ContextMenuStrip = menu,
                Visible = true
            };
            _tray.DoubleClick += (s, a) => OpenSettings();
        }

        internal void OpenSettings()
        {
            if (_settingsWin != null)
            {
                if (_settingsWin.WindowState == WindowState.Minimized) _settingsWin.WindowState = WindowState.Normal;
                _settingsWin.Activate();
                return;
            }
            _settingsWin = new SettingsWindow();
            _settingsWin.Closed += (s, a) => _settingsWin = null;
            _settingsWin.Show();
            _settingsWin.Activate();
        }
    }
}
