using System;
using System.IO;

namespace WallpaperLite
{
    // Registro simples em %AppData%\WallpaperLite\log.txt para diagnosticar problemas.
    public static class Log
    {
        public static readonly string FilePath = System.IO.Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "WallpaperLite", "log.txt");

        static readonly object L = new object();

        public static void Write(string msg)
        {
            try
            {
                lock (L)
                {
                    Directory.CreateDirectory(System.IO.Path.GetDirectoryName(FilePath));
                    if (File.Exists(FilePath) && new FileInfo(FilePath).Length > 200000) File.Delete(FilePath);
                    File.AppendAllText(FilePath, DateTime.Now.ToString("HH:mm:ss") + "  " + msg + Environment.NewLine);
                }
            }
            catch { }
        }
    }
}
